Python code for configuration model for correlation/covariance matrices


